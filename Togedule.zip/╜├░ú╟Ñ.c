#include <stdio.h>
#include <Windows.h>
//
//void gotoxy(int x,int y)
//{	
//	COORD pos={x,y};
//	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), pos); 
//}


int main() {
	//int i;
	//char schedule[14][29];
	//system("mode con:cols=130 lines=45");


	//schedule[0][0] = 1;
	//printf("%c", schedule[0][0]);
	//for(i=1; i<13; i++){
	//	if(i==12)
	//		schedule[i][0]=6;
	//	else
	//		schedule[i][0] = 6;
	//	printf("%c", schedule[i][0]);
	//}
	//printf("\n");
	//printf("\n");
	//for(i=1; i<14; i++){
	//	if(i==12)
	//		schedule[i][1] = '1';
	//	else
	//		schedule[i][1] = '1';
	//	printf("%c", schedule[i][1]);
	//}
	///*
	//for(i=0; i<29; i++){
	//	schedule[0][i+10] = 5;
	//	printf("%c", schedule[0][i]);
	//}*/

	
	/*├ ┣ */
	printf("┏━━━┳━━━━━━┳━━━━━━┳━━━━━━┳━━━━━━┳━━━━━━┓\n");
	printf("┃ 교시 ┃     월     ┃     화     ┃     수     ┃     목     ┃    금      ┃\n");
	printf("┣━━━╋━━━━━━╋━━━━━━╋━━━━━━╋━━━━━━╋━━━━━━┫\n");
	printf("┃ 01   ┃            ┃            ┃            ┃            ┃            ┃\n");
	printf("┃ 02   ┃경영학의이해┃            ┃            ┃            ┃            ┃\n");
	printf("┃ 03   ┃경영학의이해┃컴퓨터구조  ┃            ┃            ┃            ┃\n");
	printf("┃ 03   ┃경영학의이해┃            ┃컴퓨터구조  ┃            ┃운동과건강  ┃\n");
	printf("┃ 05   ┃            ┃            ┃컴퓨터구조  ┃            ┃운동과건강  ┃\n");
	printf("┃ 06   ┃            ┃            ┃            ┃사진과 영상 ┃            ┃\n");
	printf("┃ 07   ┃            ┃            ┃            ┃사진과 영상 ┃            ┃\n");
	printf("┃ 08   ┃            ┃            ┃            ┃            ┃            ┃\n");
	printf("┃ 09   ┃화학의이해  ┃알고리즘    ┃            ┃            ┃            ┃\n");
	printf("┃ 10   ┃화학의이해  ┃알고리즘    ┃            ┃            ┃            ┃\n");
	printf("┃ 11   ┃화학의이해  ┃알고리즘    ┃            ┃            ┃            ┃\n");
	printf("┃ 12   ┃            ┃            ┃            ┃            ┃            ┃\n");
	printf("┃ 13   ┃            ┃            ┃            ┃            ┃            ┃\n");
	printf("┗━━━┻━━━━━━┻━━━━━━┻━━━━━━┻━━━━━━┻━━━━━━┛\n");
}
